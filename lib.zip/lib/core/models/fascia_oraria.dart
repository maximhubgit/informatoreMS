import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

class FasciaOraria extends Equatable {
  final int minutiInizio;
  final int minutiFine;
  final int slotDisponibili;

  const FasciaOraria({
    required this.minutiInizio,
    required this.minutiFine,
    this.slotDisponibili = 1,
  });

  TimeOfDay get inizio => TimeOfDay(
        hour: minutiInizio ~/ 60,
        minute: minutiInizio % 60,
      );

  TimeOfDay get fine => TimeOfDay(
        hour: minutiFine ~/ 60,
        minute: minutiFine % 60,
      );

  int get durataMinuti => minutiFine - minutiInizio;

  FasciaOraria copyWith({
    int? minutiInizio,
    int? minutiFine,
    int? slotDisponibili,
  }) {
    return FasciaOraria(
      minutiInizio: minutiInizio ?? this.minutiInizio,
      minutiFine: minutiFine ?? this.minutiFine,
      slotDisponibili: slotDisponibili ?? this.slotDisponibili,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'minutiInizio': minutiInizio,
      'minutiFine': minutiFine,
      'slotDisponibili': slotDisponibili,
    };
  }

  factory FasciaOraria.fromJson(Map<String, dynamic> json) {
    return FasciaOraria(
      minutiInizio: json['minutiInizio'] as int,
      minutiFine: json['minutiFine'] as int,
      slotDisponibili: (json['slotDisponibili'] as num?)?.toInt() ?? 1,
    );
  }

  @override
  List<Object?> get props => [minutiInizio, minutiFine, slotDisponibili];
}
