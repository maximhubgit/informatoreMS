import 'package:equatable/equatable.dart';

import 'fascia_oraria.dart';

class Medico extends Equatable {
  final String id;
  final String nome;
  final String cognome;
  final String specializzazione;
  final String indirizzo;
  final String zonaId;
  final int periodicitaGiorni;
  final List<FasciaOraria> fasceOrarie;
  final int tempoVisitaMinuti;
  final String? calendarioAppuntamentoId; // Foreign key all'evento nel calendario

  const Medico({
    required this.id,
    required this.nome,
    required this.cognome,
    required this.specializzazione,
    required this.indirizzo,
    required this.zonaId,
    required this.periodicitaGiorni,
    required this.fasceOrarie,
    required this.tempoVisitaMinuti,
    this.calendarioAppuntamentoId,
  });

  String get nomeCompleto => '$nome $cognome';

  Medico copyWith({
    String? id,
    String? nome,
    String? cognome,
    String? specializzazione,
    String? indirizzo,
    String? zonaId,
    int? periodicitaGiorni,
    List<FasciaOraria>? fasceOrarie,
    int? tempoVisitaMinuti,
    String? calendarioAppuntamentoId,
  }) {
    return Medico(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      cognome: cognome ?? this.cognome,
      specializzazione: specializzazione ?? this.specializzazione,
      indirizzo: indirizzo ?? this.indirizzo,
      zonaId: zonaId ?? this.zonaId,
      periodicitaGiorni: periodicitaGiorni ?? this.periodicitaGiorni,
      fasceOrarie: fasceOrarie ?? this.fasceOrarie,
      tempoVisitaMinuti: tempoVisitaMinuti ?? this.tempoVisitaMinuti,
      calendarioAppuntamentoId: calendarioAppuntamentoId ?? this.calendarioAppuntamentoId,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'nome': nome,
      'cognome': cognome,
      'specializzazione': specializzazione,
      'indirizzo': indirizzo,
      'zonaId': zonaId,
      'periodicitaGiorni': periodicitaGiorni,
      'fasceOrarie': fasceOrarie.map((f) => f.toJson()).toList(),
      'tempoVisitaMinuti': tempoVisitaMinuti,
      'calendarioAppuntamentoId': calendarioAppuntamentoId,
    };
  }

  factory Medico.fromJson(Map<String, dynamic> json) {
    return Medico(
      id: json['id'] as String,
      nome: json['nome'] as String,
      cognome: json['cognome'] as String,
      specializzazione: json['specializzazione'] as String,
      indirizzo: json['indirizzo'] as String,
      zonaId: json['zonaId'] as String,
      periodicitaGiorni: (json['periodicitaGiorni'] as num).toInt(),
      fasceOrarie: (json['fasceOrarie'] as List)
          .map((e) => FasciaOraria.fromJson(e as Map<String, dynamic>))
          .toList(),
      tempoVisitaMinuti: (json['tempoVisitaMinuti'] as num).toInt(),
      calendarioAppuntamentoId: json['calendarioAppuntamentoId'] as String?,
    );
  }

  @override
  List<Object?> get props => [
        id,
        nome,
        cognome,
        specializzazione,
        indirizzo,
        zonaId,
        periodicitaGiorni,
        fasceOrarie,
        tempoVisitaMinuti,
        calendarioAppuntamentoId,
      ];
}
