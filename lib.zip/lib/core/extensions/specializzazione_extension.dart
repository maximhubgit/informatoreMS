import 'package:flutter/material.dart';

/// Extension per ottenere icona e colore in base alla specializzazione.
extension SpecializzazioneX on String {
  IconData get iconaSpecializzazione {
    return switch (this) {
      'Cardiologia' => Icons.favorite,
      'Dermatologia' => Icons.spa,
      'Ortopedia' => Icons.accessibility_new,
      'Pediatria' => Icons.child_care,
      'Ginecologia' => Icons.pregnant_woman,
      'Neurologia' => Icons.psychology,
      'Medicina Generale' => Icons.medical_services,
      'Oculistica' => Icons.visibility,
      'Otorinolaringoiatria' => Icons.hearing,
      'Endocrinologia' => Icons.water_drop,
      _ => Icons.local_hospital,
    };
  }

  Color get coloreSpecializzazione {
    return switch (this) {
      'Cardiologia' => Colors.red.shade100,
      'Dermatologia' => Colors.green.shade100,
      'Ortopedia' => Colors.blue.shade100,
      'Pediatria' => Colors.pink.shade100,
      'Ginecologia' => Colors.purple.shade100,
      'Neurologia' => Colors.teal.shade100,
      'Medicina Generale' => Colors.orange.shade100,
      'Oculistica' => Colors.indigo.shade100,
      'Otorinolaringoiatria' => Colors.amber.shade100,
      'Endocrinologia' => Colors.cyan.shade100,
      _ => Colors.grey.shade100,
    };
  }
}
