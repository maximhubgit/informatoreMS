import 'package:flutter/material.dart';
import 'package:informatoreMS/core/models/fascia_oraria.dart';

class FasciaSelector extends StatelessWidget {
  final List<FasciaOraria> fasce;
  final int? selectedMinutes;
  final ValueChanged<int> onSelect;

  const FasciaSelector({
    super.key,
    required this.fasce,
    this.selectedMinutes,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    if (fasce.isEmpty) {
      return const Text('Nessuna fascia oraria disponibile');
    }

    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: fasce.map((fascia) {
        return ActionChip(
          label: Text(
            '${fascia.inizio.formatTime()} - ${fascia.fine.formatTime()}',
            style: TextStyle(
              color: selectedMinutes == fascia.minutiInizio
                  ? Theme.of(context).colorScheme.onPrimary
                  : Theme.of(context).colorScheme.primary,
            ),
          ),
          backgroundColor: selectedMinutes == fascia.minutiInizio
              ? Theme.of(context).colorScheme.primary
              : Theme.of(context).colorScheme.primaryContainer.withValues(alpha: 0.3),
          onPressed: () => onSelect(fascia.minutiInizio),
        );
      }).toList(),
    );
  }
}

extension TimeOfDayFormat on TimeOfDay {
  String formatTime() {
    return '${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')}';
  }
}
