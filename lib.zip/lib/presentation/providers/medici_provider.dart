import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:informatoreMS/core/models/medico.dart';
import 'package:informatoreMS/data/repositories/medico_repository.dart';
import 'package:informatoreMS/presentation/providers/zone_selezionate_provider.dart';

// Import con alias per evitare conflitti
import 'package:informatoreMS/data/repositories/remote/firebase_medico_repository.dart' as firebase;

/// Repository wrapper per web che lancia errore se offline.
class _WebMedicoRepository implements MedicoRepository {
  final _firebaseRepo = firebase.FirebaseMedicoRepository();

  @override
  Future<List<Medico>> getAll() async {
    try {
      return await _firebaseRepo.getAll();
    } catch (e) {
      throw Exception('Connessione richiesta. Ricollegati a internet per usare l\'app web.');
    }
  }

  @override
  Future<void> save(Medico medico) async {
    try {
      await _firebaseRepo.save(medico);
    } catch (e) {
      throw Exception('Connessione richiesta per salvare i dati.');
    }
  }

  @override
  Future<void> delete(String id) async {
    try {
      await _firebaseRepo.delete(id);
    } catch (e) {
      throw Exception('Connessione richiesta per eliminare i dati.');
    }
  }
}

/// Provider del repository medici con logica:
/// - Web: solo Firebase (mostra errore se offline)
/// - Mobile: Firebase con persistenza offline integrata (si sincronizza automaticamente)
final medicoRepositoryProvider = Provider<MedicoRepository>((ref) {
  if (kIsWeb) {
    return _WebMedicoRepository();
  }
  return firebase.FirebaseMedicoRepository();
});

/// Provider che espone tutti i medici.
final mediciProvider = FutureProvider<List<Medico>>((ref) async {
  final repo = ref.watch(medicoRepositoryProvider);
  return repo.getAll();
});

/// Provider per salvare un medico.
final salvaMedicoProvider = Provider((ref) {
  return (Medico medico) async {
    final repo = ref.read(medicoRepositoryProvider);
    await repo.save(medico);
    ref.invalidate(mediciProvider);
  };
});

/// Provider per eliminare un medico.
final eliminaMedicoProvider = Provider((ref) {
  return (String id) async {
    final repo = ref.read(medicoRepositoryProvider);
    await repo.delete(id);
    ref.invalidate(mediciProvider);
  };
});

/// Provider derivato: medici filtrati per le zone selezionate.
final mediciFiltratiProvider = Provider<AsyncValue<List<Medico>>>((ref) {
  final zoneSelezionate = ref.watch(zoneSelezionateProvider);
  final mediciAsync = ref.watch(mediciProvider);

  return mediciAsync.when(
    data: (medici) {
      if (zoneSelezionate.isEmpty) return AsyncData(medici);
      final filtrati =
          medici.where((m) => zoneSelezionate.contains(m.zonaId)).toList();
      return AsyncData(filtrati);
    },
    loading: () => const AsyncValue.loading(),
    error: (err, stack) => AsyncValue.error(err, stack),
  );
});
