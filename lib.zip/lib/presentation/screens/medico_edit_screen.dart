import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:informatoreMS/core/models/calendario_appuntamento.dart';
import 'package:informatoreMS/core/models/fascia_oraria.dart';
import 'package:informatoreMS/core/models/medico.dart';
import 'package:informatoreMS/core/extensions/date_time_extension.dart';
import 'package:informatoreMS/presentation/providers/zone_provider.dart';
import 'package:informatoreMS/presentation/providers/calendario_provider.dart';
import 'package:informatoreMS/presentation/providers/medici_provider.dart';
import 'package:uuid/uuid.dart';

class MedicoEditScreen extends ConsumerStatefulWidget {
  final Medico? medico;

  const MedicoEditScreen({super.key, this.medico});

  @override
  ConsumerState<MedicoEditScreen> createState() => _MedicoEditScreenState();
}

class _MedicoEditScreenState extends ConsumerState<MedicoEditScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _nomeCtrl;
  late final TextEditingController _cognomeCtrl;
  late final TextEditingController _specializzazioneCtrl;
  late final TextEditingController _indirizzoCtrl;
  late final TextEditingController _periodicitaCtrl;
  late final TextEditingController _tempoVisitaCtrl;
  late String? _selectedZonaId;
  late List<FasciaOraria> _fasce;
  DateTime? _dataProssimaVisita;
  TimeOfDay? _oraProssimaVisita;

  @override
  void initState() {
    super.initState();
    final m = widget.medico;
    _nomeCtrl = TextEditingController(text: m?.nome ?? '');
    _cognomeCtrl = TextEditingController(text: m?.cognome ?? '');
    _specializzazioneCtrl = TextEditingController(text: m?.specializzazione ?? '');
    _indirizzoCtrl = TextEditingController(text: m?.indirizzo ?? '');
    _periodicitaCtrl = TextEditingController(text: m?.periodicitaGiorni.toString() ?? '30');
    _tempoVisitaCtrl = TextEditingController(text: m?.tempoVisitaMinuti.toString() ?? '30');
    _selectedZonaId = m?.zonaId;
    _fasce = List.from(m?.fasceOrarie ?? []);

    // Il caricamento avverrà nel build con FutureProvider
    // _dataProssimaVisita inizializzato con valori esistenti del medico
    if (m != null && m.calendarioAppuntamentoId != null) {
      // Carica dati appuntamento dal calendario quando disponibile
    }
  }

  @override
  void dispose() {
    _nomeCtrl.dispose();
    _cognomeCtrl.dispose();
    _specializzazioneCtrl.dispose();
    _indirizzoCtrl.dispose();
    _periodicitaCtrl.dispose();
    _tempoVisitaCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final zoneAsync = ref.watch(zoneProvider);

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.medico == null ? 'Nuovo Medico' : 'Modifica Medico'),
        centerTitle: true,
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(
              controller: _nomeCtrl,
              decoration: const InputDecoration(labelText: 'Nome'),
              validator: (v) => v?.isEmpty ?? true ? 'Campo obbligatorio' : null,
            ),
            TextFormField(
              controller: _cognomeCtrl,
              decoration: const InputDecoration(labelText: 'Cognome'),
              validator: (v) => v?.isEmpty ?? true ? 'Campo obbligatorio' : null,
            ),
            TextFormField(
              controller: _specializzazioneCtrl,
              decoration: const InputDecoration(labelText: 'Specializzazione'),
              validator: (v) => v?.isEmpty ?? true ? 'Campo obbligatorio' : null,
            ),
            TextFormField(
              controller: _indirizzoCtrl,
              decoration: const InputDecoration(labelText: 'Indirizzo'),
            ),
            const SizedBox(height: 16),
            zoneAsync.when(
              data: (zone) => DropdownButtonFormField<String>(
                value: _selectedZonaId,
                decoration: const InputDecoration(labelText: 'Zona'),
                items: zone.map((z) => DropdownMenuItem(
                      value: z.id,
                      child: Row(
                        children: [
                          Container(
                            width: 12,
                            height: 12,
                            decoration: BoxDecoration(
                              color: z.colore,
                              shape: BoxShape.circle,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text(z.nome),
                        ],
                      ),
                    )).toList(),
                onChanged: (v) => setState(() => _selectedZonaId = v),
                validator: (v) => v == null ? 'Seleziona una zona' : null,
              ),
              loading: () => const LinearProgressIndicator(),
              error: (_, __) => const SizedBox.shrink(),
            ),
            TextFormField(
              controller: _periodicitaCtrl,
              decoration: const InputDecoration(labelText: 'Periodicità (giorni)'),
              keyboardType: TextInputType.number,
            ),
            TextFormField(
              controller: _tempoVisitaCtrl,
              decoration: const InputDecoration(labelText: 'Tempo visita (minuti)'),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 16),
            _buildDataProssimaVisitaField(),
            const SizedBox(height: 16),
            _buildFasceSection(),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _salva,
              child: Text(widget.medico == null ? 'Aggiungi Medico' : 'Salva Modifiche'),
            ),
            if (widget.medico != null) ...[
              const SizedBox(height: 12),
              OutlinedButton(
                onPressed: _elimina,
                style: OutlinedButton.styleFrom(foregroundColor: Colors.red),
                child: const Text('Elimina Medico'),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildDataProssimaVisitaField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Data prossima visita (opzionale)',
          style: Theme.of(context).textTheme.labelMedium,
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: InkWell(
                onTap: _selezionaData,
                child: InputDecorator(
                  decoration: const InputDecoration(
                    labelText: 'Data',
                    suffixIcon: Icon(Icons.calendar_today),
                  ),
                  child: Text(
                    _dataProssimaVisita?.formatItalia() ?? 'Non prefissata',
                    style: TextStyle(
                      color: _dataProssimaVisita != null ? null : Colors.grey,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: InkWell(
                onTap: _selezionaOra,
                child: InputDecorator(
                  decoration: const InputDecoration(
                    labelText: 'Ora',
                    suffixIcon: Icon(Icons.access_time),
                  ),
                  child: Text(
                    _oraProssimaVisita?.formatTime() ?? 'Seleziona ora',
                    style: TextStyle(
                      color: _oraProssimaVisita != null ? null : Colors.grey,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Text(
          'La data sarà inserita direttamente nel calendario con stato "Confermato"',
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Colors.grey.shade600,
                fontStyle: FontStyle.italic,
              ),
        ),
      ],
    );
  }

  Future<void> _selezionaData() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _dataProssimaVisita ?? DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365 * 2)),
    );
    if (picked == null || !mounted) return;
    setState(() => _dataProssimaVisita = picked);
  }

  Future<void> _selezionaOra() async {
    final picked = await showTimePicker(
      context: context,
      initialTime: _oraProssimaVisita ?? const TimeOfDay(hour: 9, minute: 0),
    );
    if (picked == null || !mounted) return;
    setState(() => _oraProssimaVisita = picked);
  }

  Widget _buildFasceSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Fasce Orarie',
          style: Theme.of(context).textTheme.titleMedium,
        ),
        const SizedBox(height: 8),
        ..._fasce.asMap().entries.map((entry) {
          final index = entry.key;
          final fascia = entry.value;
          return Card(
            margin: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              title: Text(
                '${fascia.inizio.formatTime()} - ${fascia.fine.formatTime()}',
              ),
              trailing: IconButton(
                icon: const Icon(Icons.delete, color: Colors.red),
                onPressed: () => setState(() => _fasce.removeAt(index)),
              ),
            ),
          );
        }),
        TextButton.icon(
          onPressed: _aggiungiFascia,
          icon: const Icon(Icons.add),
          label: const Text('Aggiungi Fascia'),
        ),
      ],
    );
  }

  Future<void> _aggiungiFascia() async {
    final timeInizio = await showTimePicker(
      context: context,
      initialTime: const TimeOfDay(hour: 9, minute: 0),
    );
    if (timeInizio == null) return;

    if (!mounted) return;

    final timeFine = await showTimePicker(
      context: context,
      initialTime: const TimeOfDay(hour: 12, minute: 0),
    );
    if (timeFine == null) return;

    setState(() {
      _fasce.add(FasciaOraria(
        minutiInizio: timeInizio.hour * 60 + timeInizio.minute,
        minutiFine: timeFine.hour * 60 + timeFine.minute,
      ));
    });
  }

  void _salva() {
    if (!_formKey.currentState!.validate()) return;

    final medicoId = widget.medico?.id ?? const Uuid().v4();
    String? calendarioAppuntamentoId;

    // Prima salviamo/salviamo il medico
    final nuovoMedico = (widget.medico ?? Medico(
      id: medicoId,
      nome: '',
      cognome: '',
      specializzazione: '',
      indirizzo: '',
      zonaId: '',
      periodicitaGiorni: 30,
      fasceOrarie: [],
      tempoVisitaMinuti: 30,
    )).copyWith(
      nome: _nomeCtrl.text,
      cognome: _cognomeCtrl.text,
      specializzazione: _specializzazioneCtrl.text,
      indirizzo: _indirizzoCtrl.text,
      zonaId: _selectedZonaId!,
      periodicitaGiorni: int.parse(_periodicitaCtrl.text),
      fasceOrarie: _fasce,
      tempoVisitaMinuti: int.parse(_tempoVisitaCtrl.text),
    );

    ref.read(salvaMedicoProvider)(nuovoMedico);

    // Poi gestiamo l'appuntamento
    if (_dataProssimaVisita != null) {
      final dateTimeCompleta = DateTime(
        _dataProssimaVisita!.year,
        _dataProssimaVisita!.month,
        _dataProssimaVisita!.day,
        _oraProssimaVisita?.hour ?? 9,
        _oraProssimaVisita?.minute ?? 0,
      );

      // Cerchiamo prima se esiste già un appuntamento NON CONCLUSO per questo medico
      final appuntamenti = ref.read(calendarioProvider).valueOrNull ?? [];
      final appEsistente = appuntamenti
          .where((a) =>
              a.medicoId == medicoId &&
              !a.stato.isConcluso)
          .firstOrNull;

      if (appEsistente != null) {
        // Esiste già un appuntamento per questo medico - lo aggiorniamo come concordato
        calendarioAppuntamentoId = appEsistente.id;
        ref.read(salvaAppuntamentoProvider)(appEsistente.copyWith(
          data: dateTimeCompleta,
          stato: StatoCalendario.concordato,
          note: 'Aggiornato dall\'anagrafica medico',
        ));
      } else {
        // Nessun appuntamento esistente, ne creiamo uno nuovo come CONCORDATO
        final nuovoAppuntamento = CalendarioAppuntamento(
          id: const Uuid().v4(),
          medicoId: medicoId,
          data: dateTimeCompleta,
          stato: StatoCalendario.concordato,
          note: 'Inserito dall\'anagrafica medico',
          dataCreazione: DateTime.now(),
        );
        ref.read(salvaAppuntamentoProvider)(nuovoAppuntamento);
        calendarioAppuntamentoId = nuovoAppuntamento.id;
      }
    }

    // Aggiorniamo il medico con l'ID appuntamento (se necessario)
    if (calendarioAppuntamentoId != null &&
        (widget.medico?.calendarioAppuntamentoId == null ||
         widget.medico?.calendarioAppuntamentoId != calendarioAppuntamentoId)) {
      ref.read(salvaMedicoProvider)(nuovoMedico.copyWith(
        calendarioAppuntamentoId: calendarioAppuntamentoId,
      ));
    } else if (_dataProssimaVisita == null && widget.medico?.calendarioAppuntamentoId != null) {
      // Nessuna data più selezionata, rimuoviamo il collegamento
      ref.read(salvaMedicoProvider)(nuovoMedico.copyWith(
        calendarioAppuntamentoId: null,
      ));
    }

    ref.refresh(mediciProvider);
    ref.refresh(calendarioProvider);

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Salvataggio completato')),
    );
    Navigator.of(context).pop();
  }

  Future<void> _elimina() async {
    if (widget.medico == null) return;

    final conferma = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Confermi l\'eliminazione?'),
        content: Text('Il medico ${widget.medico!.nomeCompleto} verrà rimosso.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Annulla'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Elimina'),
          ),
        ],
      ),
    );

    if (conferma == true && mounted) {
      await ref.read(medicoRepositoryProvider).delete(widget.medico!.id);
      ref.refresh(mediciProvider);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Medico eliminato')),
      );
      Navigator.of(context).pop();
    }
  }
}
