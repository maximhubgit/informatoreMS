import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:informatoreMS/core/models/medico.dart';
import 'package:informatoreMS/core/models/fascia_oraria.dart';
import 'package:informatoreMS/data/repositories/medico_repository.dart';

/// Repository Firebase per i medici.
class FirebaseMedicoRepository implements MedicoRepository {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  @override
  Future<List<Medico>> getAll() async {
    final snapshot = await _db.collection('medici').get();
    return snapshot.docs.map((doc) {
      final data = doc.data();
      return Medico(
        id: doc.id,
        nome: data['nome'] ?? '',
        cognome: data['cognome'] ?? '',
        specializzazione: data['specializzazione'] ?? '',
        indirizzo: data['indirizzo'] ?? '',
        zonaId: data['zonaId'] ?? '',
        periodicitaGiorni: data['periodicitaGiorni'] ?? 30,
        fasceOrarie: (data['fasceOrarie'] as List<dynamic>?)
            ?.map((f) => FasciaOraria.fromJson(Map<String, dynamic>.from(f)))
            .toList() ?? [],
        tempoVisitaMinuti: data['tempoVisitaMinuti'] ?? 30,
        calendarioAppuntamentoId: data['calendarioAppuntamentoId'] as String?,
      );
    }).toList();
  }

  @override
  Future<void> save(Medico medico) async {
    await _db.collection('medici').doc(medico.id).set({
      'nome': medico.nome,
      'cognome': medico.cognome,
      'specializzazione': medico.specializzazione,
      'indirizzo': medico.indirizzo,
      'zonaId': medico.zonaId,
      'periodicitaGiorni': medico.periodicitaGiorni,
      'fasceOrarie': medico.fasceOrarie.map((f) => f.toJson()).toList(),
      'tempoVisitaMinuti': medico.tempoVisitaMinuti,
      'calendarioAppuntamentoId': medico.calendarioAppuntamentoId,
    });
  }

  @override
  Future<void> delete(String id) async {
    await _db.collection('medici').doc(id).delete();
  }
}
