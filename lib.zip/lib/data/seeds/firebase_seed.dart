import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:informatoreMS/core/firebase_options.dart';

/// Script per popolare il database Firebase con dati di esempio.
/// Richiamare da UI dell'app in modalità debug.
class FirebaseSeeder {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Future<void> seed() async {
    // Firebase già inizializzato dall'app

    // Crea zone
    await _seedZone();

    // Crea specializzazioni
    await _seedSpecializzazioni();

    // Crea medici (dopo le zone)
    await _seedMedici();

    // Crea appuntamenti di esempio
    await _seedAppuntamenti();

    print('Seeding completato!');
  }

  Future<void> _seedZone() async {
    final zone = [
      {'nome': 'Centro', 'coloreHex': '#FF6B6B'},
      {'nome': 'Nord', 'coloreHex': '#4ECDC4'},
      {'nome': 'Sud', 'coloreHex': '#45B7D1'},
      {'nome': 'Est', 'coloreHex': '#96CEB4'},
      {'nome': 'Ovest', 'coloreHex': '#FFEAA7'},
    ];

    for (final z in zone) {
      await _db.collection('zone').add(z);
    }
    print('Zone inserite: ${zone.length}');
  }

  Future<void> _seedSpecializzazioni() async {
    final specializzazioni = [
      'Cardiologia',
      'Dermatologia',
      'Endocrinologia',
      'Gastroenterologia',
      'Ortopedia',
      'Pediatria',
    ];

    for (final s in specializzazioni) {
      await _db.collection('specializzazioni').add({'nome': s});
    }
    print('Specializzazioni inserite: ${specializzazioni.length}');
  }

  Future<void> _seedMedici() async {
    final zoneSnapshot = await _db.collection('zone').get();
    final zoneMap = {for (final z in zoneSnapshot.docs) z.id: z.id};

    final medici = [
      {
        'nome': 'Mario',
        'cognome': 'Rossi',
        'specializzazione': 'Cardiologia',
        'indirizzo': 'Via Roma 1',
        'zonaId': zoneMap.values.first,
        'periodicitaGiorni': 30,
        'fasceOrarie': [
          {'minutiInizio': 360, 'minutiFine': 720}, // 9:00-12:00
          {'minutiInizio': 780, 'minutiFine': 1020}, // 13:00-17:00
        ],
        'tempoVisitaMinuti': 30,
      },
      {
        'nome': 'Luigi',
        'cognome': 'Verdi',
        'specializzazione': 'Dermatologia',
        'indirizzo': 'Via Milano 2',
        'zonaId': zoneMap.values.firstOrNull ?? '',
        'periodicitaGiorni': 60,
        'fasceOrarie': [
          {'minutiInizio': 480, 'minutiFine': 720}, // 8:00-12:00
        ],
        'tempoVisitaMinuti': 30,
      },
      {
        'nome': 'Anna',
        'cognome': 'Bianchi',
        'specializzazione': 'Pediatria',
        'indirizzo': 'Via Napoli 3',
        'zonaId': zoneMap.values.firstOrNull ?? '',
        'periodicitaGiorni': 28,
        'fasceOrarie': [
          {'minutiInizio': 540, 'minutiFine': 900}, // 9:00-15:00
        ],
        'tempoVisitaMinuti': 30,
      },
    ];

    for (final m in medici) {
      await _db.collection('medici').add(m);
    }
    print('Medici inseriti: ${medici.length}');
  }

  Future<void> _seedAppuntamenti() async {
    final mediciSnapshot = await _db.collection('medici').get();
    final mediciMap = {for (final m in mediciSnapshot.docs) m.id: m.id};

    final appuntamenti = [
      {
        'medicoId': mediciMap.values.first,
        'data': DateTime(2026, 4, 15, 9, 30).toIso8601String(),
        'note': 'Controllo periodico',
        'stato': 'fatto',
      },
      {
        'medicoId': mediciMap.values.elementAt(1),
        'data': DateTime(2026, 3, 20, 8, 30).toIso8601String(),
        'stato': 'fatto',
      },
      {
        'medicoId': mediciMap.values.elementAt(2),
        'data': DateTime(2026, 6, 20, 10, 0).toIso8601String(),
        'stato': 'concordato',
        'note': 'Visita di controllo',
      },
    ];

    for (final a in appuntamenti) {
      await _db.collection('calendario_appuntamenti').add(a);
    }
    print('Appuntamenti inseriti: ${appuntamenti.length}');
  }
}

// Per eseguire: dart run lib/data/seeds/firebase_seed.dart
void main() async {
  final seeder = FirebaseSeeder();
  await seeder.seed();
}
