import 'package:informatoreMS/core/models/medico.dart';
import 'package:informatoreMS/core/models/fascia_oraria.dart';

/// Provider mock statico per i medici con fasce orarie di esempio.
class MockMedicoProvider {
  MockMedicoProvider._();

  static final List<Medico> medici = [
    const Medico(
      id: 'm1',
      nome: 'Mario',
      cognome: 'Rossi',
      specializzazione: 'Cardiologia',
      indirizzo: 'Via Roma 10, Centro Storico',
      zonaId: 'z1',
      periodicitaGiorni: 30,
      fasceOrarie: [
        FasciaOraria(minutiInizio: 9 * 60, minutiFine: 12 * 60),
        FasciaOraria(minutiInizio: 15 * 60, minutiFine: 18 * 60),
      ],
      tempoVisitaMinuti: 30,
    ),
    const Medico(
      id: 'm2',
      nome: 'Laura',
      cognome: 'Bianchi',
      specializzazione: 'Dermatologia',
      indirizzo: 'Via Milano 5, Periferia Nord',
      zonaId: 'z2',
      periodicitaGiorni: 60,
      fasceOrarie: [
        FasciaOraria(minutiInizio: 8 * 60 + 30, minutiFine: 11 * 60 + 30),
      ],
      tempoVisitaMinuti: 20,
    ),
    const Medico(
      id: 'm3',
      nome: 'Giuseppe',
      cognome: 'Verdi',
      specializzazione: 'Ortopedia',
      indirizzo: 'Piazza Garibaldi 1, Centro Storico',
      zonaId: 'z1',
      periodicitaGiorni: 45,
      fasceOrarie: [
        FasciaOraria(minutiInizio: 10 * 60, minutiFine: 13 * 60),
        FasciaOraria(minutiInizio: 16 * 60, minutiFine: 19 * 60),
      ],
      tempoVisitaMinuti: 45,
    ),
    const Medico(
      id: 'm4',
      nome: 'Anna',
      cognome: 'Neri',
      specializzazione: 'Pediatria',
      indirizzo: 'Via Napoli 20, Periferia Sud',
      zonaId: 'z3',
      periodicitaGiorni: 30,
      fasceOrarie: [
        FasciaOraria(minutiInizio: 9 * 60, minutiFine: 12 * 60),
        FasciaOraria(minutiInizio: 14 * 60, minutiFine: 17 * 60),
      ],
      tempoVisitaMinuti: 30,
    ),
    const Medico(
      id: 'm5',
      nome: 'Francesca',
      cognome: 'Gialli',
      specializzazione: 'Ginecologia',
      indirizzo: 'Corso Italia 50, Zona Ovest',
      zonaId: 'z4',
      periodicitaGiorni: 90,
      fasceOrarie: [
        FasciaOraria(minutiInizio: 8 * 60, minutiFine: 12 * 60),
      ],
      tempoVisitaMinuti: 40,
    ),
    const Medico(
      id: 'm6',
      nome: 'Roberto',
      cognome: 'Blu',
      specializzazione: 'Neurologia',
      indirizzo: 'Via Torino 15, Periferia Nord',
      zonaId: 'z2',
      periodicitaGiorni: 30,
      fasceOrarie: [
        FasciaOraria(minutiInizio: 9 * 60, minutiFine: 13 * 60),
        FasciaOraria(minutiInizio: 15 * 60, minutiFine: 18 * 60),
      ],
      tempoVisitaMinuti: 30,
    ),
  ];
}
